package br.edu.unis.calculoimc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText edtPeso , edtAltura;
    Button btnFazerCalculo;
    TextView txtResultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        carregaComponentes();
    }

    protected void carregaComponentes(){
        edtPeso = findViewById(R.id.edtPeso);
        edtAltura = findViewById(R.id.edtAltura);
        btnFazerCalculo = findViewById(R.id.btnFazerCalculo);
        txtResultado = findViewById(R.id.txtResultado);
    }

    protected void configurarBotaoCalcular() {
        btnFazerCalculo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String resultado = realizaCalculo();
                exibiResultado(resultado);
                limpaCampos();
            }
        });
    }

    protected void realizaCalculo(){
        float peso = Float.parseFloat(edtPeso.getText().toString());
        float altura = Float.parseFloat(edtAltura.getText().toString());
        float alturaemMetro = altura/100;
        float IMC = peso/(alturaemMetro*alturaemMetro);

        if (IMC < 16) {
            return "Magreza grave";
        } else if (IMC >= 16 && IMC < 17) {
            return "Magreza moderada";
        } else if (IMC >= 17 && IMC < 18.5) {
            return "Magreza leve";
        } else if (IMC >= 18.5 && IMC < 25) {
            return "Saudável";
        } else if (IMC >= 25 && IMC < 30) {
            return "Sobrepeso";
        } else if (IMC >= 30 && IMC < 35) {
            return "Obesidade Grau I";
        } else if (IMC >= 35 && IMC < 40) {
            return "Obesidade Grau II";
        } else if (IMC >= 40) {
            return "Obesidade Grau III (mórbida)";
        } else {
            return "Não foi possível calcular";
        }
    }

    protected void exibiResultado(String resultado){
        txtResultado.setText(resultado);
    }

    protected void limpaCampos(){
        edtPeso.setText("");
        edtPeso.requestFocus();
        edtAltura.setText("");
        edtAltura.requestFocus();
    }
}